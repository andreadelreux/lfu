<template>
  <div class="assets--card">
    Hello
  </div>
</template>

<script>
export default {
  name: 'Card',
  data () {
    return {
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style>
.assets--card{
  width: 1170px;/* BG: */
  background: #FFF;
  border: 1px solid #CCCCCC;
  border-radius: 2px;
  margin: auto;
  position: relative;
  overflow: hidden;
}
</style>
